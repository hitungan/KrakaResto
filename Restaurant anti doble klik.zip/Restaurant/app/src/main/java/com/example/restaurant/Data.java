package com.example.restaurant;

import java.util.ArrayList;

public class Data {
    public static String tableNumber;
    public static boolean listenerState = false;
    public static int tablePosition = 0;
    public static ArrayList<Food> foodList = new ArrayList<>();
    public static ArrayList<Food> drinkList = new ArrayList<>();
    public static ArrayList<Table> tableList = new ArrayList<>();
    public static double totalharga = 0;
    public static int maxTable = 0;
}
